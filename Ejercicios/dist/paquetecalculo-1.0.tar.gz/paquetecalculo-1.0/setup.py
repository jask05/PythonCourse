# -*- coding: utf-8 -*-
from setuptools import setup

setup(
    name = "paquetecalculo",
    version = "1.0",
    description = "Paquete de redondeo y potencia",
    author = "Jask",
    author_email = "email@email.com",
    url = "https://www.web.com",
    packages = ["paquetes", "paquetes.redondeo_potencia"]
)